/*	@(#)test4.c	1.3 89/01/10 NFS Rev 2 Testsuite	*/
/*
 * Test setattr, getattr and lookup
 *
 * Creates the files in the test directory - does not create a directory
 * tree.
 *
 * Uses the following important system calls against the server:
 *
 *	chdir()
 *	mkdir()		(for initial directory creation if not -m)
 *	creat()
 *	chmod()
 *	stat()
 */

#include "tests.h"


int Tflag = 0;		/* print timing */
int Hflag = 0;		/* print help message */
int Fflag = 0;		/* test function only;  set count to 1, negate -t */
int Nflag = 0;		/* Suppress directory operations */

#ifdef ANSI
void usage(void);
#endif

void
usage()
{
	fprintf(stdout, "usage: %s [-htfn] [files count]\n", Myname);
	fprintf(stdout, "  Flags:  h    Help - print this usage info\n");
	fprintf(stdout, "          t    Print execution time statistics\n");
	fprintf(stdout, "          f    Test function only (negate -t)\n");
	fprintf(stdout, "          n    Suppress test directory create operations\n");
}

#ifdef ANSI
void main(int argc, char *argv[]);
#endif
void
main(argc, argv)
	int argc;
	char *argv[];
{
	int files = 10;		/* number of files in each dir */
	int fi;
	int count = 50;	/* times to do each file */
	int ct;
	int totfiles = 0;
	int totdirs = 0;
	char *fname = FNAME;
	struct timeval time;
	char str[MAXPATHLEN];
	struct stat statb;
	char *opts;

	umask(0);
	setbuf(stdout, NULL);
	Myname = *argv++;
	argc--;
	while (argc && **argv == '-') {
		for (opts = &argv[0][1]; *opts; opts++) {
			switch (*opts) {
				case 'h':	/* help */
					usage();
					exit(1);

				case 't':	/* time */
					Tflag++;
					break;
				
				case 'f':	/* funtionality */
					Fflag++;
					break;
				
				case 'n':	/* suppress initial directory */
					Nflag++;
					break;
				
				default:
					error("unknown option '%c'", *opts);
					usage();
					exit(1);
			}
		}
		argc--;
		argv++;
	}

	if (argc) {
		files = (int) getparm(*argv, 1L, "files");
		argv++;
		argc--;
	}
	if (argc) {
		count = (int) getparm(*argv, 1L, "count");
		argv++;
		argc--;
	}
	if (argc) {
		fname = *argv;
		argc--;
		argv++;
	}
	if (argc) {
		usage();
		exit(1);
	}

	if (Fflag) {
		Tflag = 0;
		count = 1;
	}

	if (!Nflag)
		testdir(NULL);
	else
		mtestdir(NULL);

	dirtree(1, files, 0, fname, DNAME, &totfiles, &totdirs);

	fprintf(stdout, "%s: setattr, getattr, and lookup\n", Myname);

	if (Tflag) {
		starttime();
	}

	for (ct = 0; ct < count; ct++) {
		for (fi = 0; fi < files; fi++) {
			sprintf(str, "%s%d", fname, fi);
			if (chmod(str, CHMOD_NO) < 0) {
				error("can't chmod 0 %s", str);
				exit(0);
			}
			if (stat(str, &statb) < 0) {
				error("can't stat %s", str);
				exit(1);
			}
			if ((statb.st_mode & CHMOD_MASK) != CHMOD_NO) {
				error("%s has mode %o after chmod 0",
				    str, (statb.st_mode & CHMOD_MASK));
				exit(1);
			}
			if (chmod(str, CHMOD_YES) < 0) {
				error("can't chmod 0666 %s", str);
				exit(0);
			}
			if (stat(str, &statb) < 0) {
				error("can't stat %s", str);
				exit(1);
			}
			if ((statb.st_mode & CHMOD_MASK) != CHMOD_YES) {
				error("%s has mode %o after chmod 0666",
				    str, (statb.st_mode & CHMOD_MASK));
				exit(1);
			}
		}
	}

	if (Tflag) {
		endtime(&time);
	}
	fprintf(stdout, "\t%d chmods and stats on %d files",
		files * count * 2, files);
	if (Tflag) {
		printtimes(&time, 0L);
	}
	fprintf(stdout, "\n");
	/* XXX REMOVE DIRECTORY TREE? */
	complete();
}
