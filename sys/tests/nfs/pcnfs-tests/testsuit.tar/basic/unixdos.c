#ifdef DOS

#include <dos.h>
#include "unixdos.h"

void
gettimeofday(struct timeval *TV, struct timezone *TimeZone)
{
	struct dostime_t DosTime;
	_dos_gettime(&DosTime);
	TV->tv_sec = DosTime.hour * 3600L
		+ DosTime.minute * 60L
		+ DosTime.second;
	TV->tv_usec = DosTime.hsecond * 10000L;
}

#endif
