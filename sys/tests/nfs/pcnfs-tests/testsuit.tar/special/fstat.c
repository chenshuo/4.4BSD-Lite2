/*	@(#)fstat.c	1.1 88/10/12 NFS Rev 2 Testsuite	*/
/*
 * test statfs for file count
 */
#include <tests.h>

#ifdef ANSI
void
main(int argc, char *argv[]);
#endif

void
main(argc, argv)
	int argc;
	char *argv[];
{
	struct statfs fs;
	char *name = ".";

	if (argc > 2) {
		fprintf(stderr, "usage: %s [path]\n", argv[0]);
		exit(1);
	}
	if (argc == 2) {
		name = argv[1];
	}
	fs.f_files = 0;
	fs.f_ffree = 0;
	if (statfs(name, &fs) < 0) {
		perror(argv[1]);
		exit(1);
	}
	printf("inodes %d free %d\n", fs.f_files, fs.f_ffree);
	exit(0);
}
