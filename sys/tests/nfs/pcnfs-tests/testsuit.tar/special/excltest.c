/*	@(#)excltest.c	1.1 88/10/12 NFS Rev 2 Testsuite	*/
/*
 * test exclusive create
 */

#include <tests.h>
void main(int argc, char *argv[]);

void
main(argc, argv)
	int argc;
	char *argv[];
{
	if (argc > 2) {
		fprintf(stderr, "usage: %s [count]\n", argv[0]);
		exit(1);
	}
	if (argc == 2) {
		int count = atoi(argv[1]);
		for (; count; count--) {
			open("exctest.fil", O_CREAT | O_EXCL, CHMOD_YES);
		}
		exit(0);
	}
	unlink("exctest.fil");
	if (open("exctest.fil", O_CREAT | O_EXCL, CHMOD_YES) < 0) {
		perror("exctest.fil");
		exit(1);
	}
	if (open("exctest.fil", O_CREAT | O_EXCL, CHMOD_YES) < 0) {
		perror("exctest.fil 2");
		exit(0);
	}
	exit(0);
}
